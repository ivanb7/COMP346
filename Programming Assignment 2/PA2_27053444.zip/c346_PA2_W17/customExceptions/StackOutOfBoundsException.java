package customExceptions;

public class StackOutOfBoundsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3718124756345624425L;

	public StackOutOfBoundsException(String string) {
		super(string);
	}

}
